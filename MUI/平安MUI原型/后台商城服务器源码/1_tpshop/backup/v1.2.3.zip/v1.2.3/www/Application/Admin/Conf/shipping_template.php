<?php
return array(
//    '网店-省份'=>'{$shop.province}',
//    '网店-城市'=>'{$shop.city}',
    '网店-名称'=>'{$shop.store_name}',
//    '网店-区/县'=>'{$shop.district}',
    '网店-联系电话'=>'{$shop.phone}',
    '网店-地址'=>'{$shop.address}',

    '收件人-省份'=>'{$order.province}',
    '收件人-城市'=>'{$order.city}',
    '收件人-区/县'=>'{$order.district}',
    '收件人-手机'=>'{$order.mobile}',
    '收件人-邮编'=>'{$order.zipcode}',
    '收件人-地址'=>'{$order.address}',
    '收件人-详细地址'=>'{$order.full_address}',
    '收件人-姓名'=>'{$order.consignee}',

    '年份'=>'{$date.year}',
    '月份'=>'{$date.month}',
    '日期'=>'{$date.day}',

    '订单-订单号'=>'{$order.order_sn}',
    '订单-备注'=>'{$order.note}',
);